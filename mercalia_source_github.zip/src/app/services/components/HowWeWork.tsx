'use client';

import React, { useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';

const stepIcons = [
  <svg key="0" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>,
  <svg key="1" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>,
  <svg key="2" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>,
  <svg key="3" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" /><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg>,
  <svg key="4" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /><polyline points="9 15 12 18 16 13" /></svg>,
  <svg key="5" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>,
];

export default function HowWeWork() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { t } = useLanguage();

  useEffect(() => {
    const reveals = sectionRef?.current?.querySelectorAll('.reveal');
    if (!reveals) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach(e => { if (e.isIntersecting) e.target.classList.remove('hidden-init'); }),
      { threshold: 0.08 }
    );
    reveals?.forEach(el => observer?.observe(el));
    return () => observer?.disconnect();
  }, []);

  const steps = [0, 1, 2, 3, 4, 5]?.map((i) => ({
    step: `0${i + 1}`,
    title: t(`services.step.${i}.title`),
    description: t(`services.step.${i}.description`),
    icon: stepIcons?.[i],
  }));

  return (
    <section className="py-24 bg-brand-bgDark" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="text-center mb-16">
          <span className="section-label block mb-3 reveal hidden-init">{t('services.howWeWork.label')}</span>
          <h2 className="font-display font-bold text-primary reveal hidden-init stagger-1" style={{ fontSize: 'clamp(32px, 4vw, 48px)', letterSpacing: '-0.025em', lineHeight: '1.08' }}>
            {t('services.howWeWork.title1')}
            <br />
            <span className="italic font-light text-secondary">{t('services.howWeWork.titleItalic')}</span>
          </h2>
          <p className="text-brand-muted max-w-xl mx-auto mt-4 leading-relaxed reveal hidden-init stagger-2">{t('services.howWeWork.description')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {steps?.map((step, i) => (
            <div key={step?.step} className={`relative bg-white rounded-2xl p-7 border border-brand-border hover:border-secondary hover:shadow-card-hover transition-all duration-400 reveal hidden-init stagger-${Math.min(i + 1, 4)}`}>
              <div className="flex items-start justify-between mb-6">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center text-secondary" style={{ background: 'rgba(26, 122, 138, 0.08)', border: '1px solid rgba(26,122,138,0.15)' }}>{step?.icon}</div>
                <span className="font-display font-bold text-5xl leading-none" style={{ color: 'rgba(11, 44, 74, 0.07)' }}>{step?.step}</span>
              </div>
              <h3 className="font-semibold text-brand-fg text-lg mb-2">{step?.title}</h3>
              <p className="text-brand-muted text-sm leading-relaxed">{step?.description}</p>
              {i < steps?.length - 1 && (
                <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-secondary rounded-full hidden lg:flex items-center justify-center z-10 shadow-sm">
                  <svg width="12" height="12" fill="none" stroke="white" strokeWidth="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7" /></svg>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}