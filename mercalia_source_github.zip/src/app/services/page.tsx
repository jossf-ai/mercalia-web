import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ServicesHero from './components/ServicesHero';
import ServicesGrid from './components/ServicesGrid';
import HowWeWork from './components/HowWeWork';
import ServicesCTA from './components/ServicesCTA';

export default function ServicesPage() {
  return (
    <main className="bg-brand-bg overflow-x-hidden">
      <div className="noise-overlay" />
      <Header />
      <ServicesHero />
      <ServicesGrid />
      <HowWeWork />
      <ServicesCTA />
      <Footer />
    </main>
  );
}