'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import AppLogo from '@/components/ui/AppLogo';
import { useLanguage } from '@/context/LanguageContext';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();
  const { lang, setLang, t } = useLanguage();

  const navLinks = [
    { labelKey: 'nav.home', href: '/homepage' },
    { labelKey: 'nav.services', href: '/services' },
    { labelKey: 'nav.products', href: '/products' },
    { labelKey: 'nav.compliance', href: '/compliance' },
    { labelKey: 'nav.contact', href: '/contact' },
  ];

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  const isActive = (href: string) => pathname === href;
  const isHeroPage = pathname === '/homepage' || pathname === '/';

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
          scrolled || !isHeroPage
            ? 'bg-white/97 backdrop-blur-md shadow-md border-b border-[#1a2332]/10'
            : 'bg-transparent'
        }`}
      >
        {/* Top accent line */}
        {(scrolled || !isHeroPage) && (
          <div className="absolute top-0 left-0 right-0 h-[3px]" style={{ background: 'linear-gradient(90deg, #1a2332 0%, #00c8d4 50%, #1a2332 100%)' }} />
        )}

        <div className="max-w-7xl mx-auto px-6 md:px-10 flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/homepage" className="flex items-center gap-3 group" aria-label="MercaliaConnect Home">
            <AppLogo
              src="/assets/images/logo_mercalia_separado-1772891797274.png"
              size={scrolled || !isHeroPage ? 68 : 84}
              className="transition-all duration-300 group-hover:scale-105"
            />
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`relative px-4 py-2 text-sm font-medium transition-colors duration-200 rounded-md ${
                  isActive(link.href)
                    ? 'text-[#00c8d4]'
                    : scrolled || !isHeroPage
                    ? 'text-[#1a2332] hover:text-[#00c8d4]'
                    : 'text-white/90 hover:text-white'
                }`}
              >
                {t(link.labelKey)}
                {isActive(link.href) && (
                  <span className="absolute bottom-0.5 left-4 right-4 h-0.5 bg-[#00c8d4] rounded-full" />
                )}
              </Link>
            ))}
          </nav>

          {/* Right side: Language switcher + CTA */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Language Toggle */}
            <div
              className={`flex items-center rounded-lg overflow-hidden border text-xs font-bold ${
                scrolled || !isHeroPage
                  ? 'border-[#1a2332]/20'
                  : 'border-white/30'
              }`}
            >
              <button
                onClick={() => setLang('es')}
                className={`px-3 py-1.5 transition-all duration-200 ${
                  lang === 'es' ?'bg-[#1a2332] text-white'
                    : scrolled || !isHeroPage
                    ? 'text-[#6b7280] hover:text-[#1a2332]'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                ES
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-3 py-1.5 transition-all duration-200 ${
                  lang === 'en' ?'bg-[#1a2332] text-white'
                    : scrolled || !isHeroPage
                    ? 'text-[#6b7280] hover:text-[#1a2332]'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                EN
              </button>
            </div>

            <Link
              href="/contact"
              className={`px-5 py-2.5 text-sm font-semibold rounded-lg transition-all duration-300 ${
                scrolled || !isHeroPage
                  ? 'bg-[#1a2332] text-white hover:bg-[#00c8d4] hover:shadow-lg hover:shadow-[#00c8d4]/20'
                  : 'bg-white/15 text-white border border-white/30 hover:bg-white/25'
              }`}
            >
              {t('nav.contactUs')}
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            className={`lg:hidden p-2 rounded-md transition-colors ${
              scrolled || !isHeroPage ? 'text-[#1a2332]' : 'text-white'
            }`}
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            <div className="w-6 flex flex-col gap-1.5">
              <span className={`block h-0.5 bg-current rounded transition-all duration-300 ${menuOpen ? 'rotate-45 translate-y-2' : ''}`} />
              <span className={`block h-0.5 bg-current rounded transition-all duration-300 ${menuOpen ? 'opacity-0' : ''}`} />
              <span className={`block h-0.5 bg-current rounded transition-all duration-300 ${menuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
            </div>
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 lg:hidden transition-all duration-500 ${
          menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="absolute inset-0 backdrop-blur-xl flex flex-col pt-24 px-8 pb-12" style={{ background: 'linear-gradient(160deg, #1a2332 0%, #0B2C4A 60%, #0d3a4a 100%)' }}>
          {/* Cyan accent line top */}
          <div className="absolute top-0 left-0 right-0 h-1" style={{ background: 'linear-gradient(90deg, #1a2332, #00c8d4, #1a2332)' }} />

          <div className="absolute top-6 left-8">
            <AppLogo
              src="/assets/images/logo_mercalia_separado-1772891797274.png"
              size={64}
            />
          </div>

          <nav className="flex flex-col gap-2 flex-1">
            {navLinks.map((link, i) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className={`text-3xl font-display font-bold py-3 border-b border-white/10 transition-all duration-300 ${
                  isActive(link.href) ? 'text-[#00c8d4]' : 'text-white hover:text-[#00c8d4]'
                }`}
                style={{ transitionDelay: `${i * 50}ms` }}
              >
                {t(link.labelKey)}
              </Link>
            ))}
          </nav>

          {/* Mobile language switcher */}
          <div className="flex items-center gap-3 mt-6 mb-4">
            <span className="text-white/40 text-sm font-medium">Idioma / Language:</span>
            <div className="flex items-center rounded-lg overflow-hidden border border-white/30">
              <button
                onClick={() => setLang('es')}
                className={`px-4 py-2 text-sm font-bold transition-all duration-200 ${
                  lang === 'es' ? 'bg-[#00c8d4] text-[#1a2332]' : 'text-white/60 hover:text-white'
                }`}
              >
                ES
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-4 py-2 text-sm font-bold transition-all duration-200 ${
                  lang === 'en' ? 'bg-[#00c8d4] text-[#1a2332]' : 'text-white/60 hover:text-white'
                }`}
              >
                EN
              </button>
            </div>
          </div>

          <Link
            href="/contact"
            onClick={() => setMenuOpen(false)}
            className="text-center justify-center py-4 rounded-xl font-semibold text-[#1a2332] transition-all duration-300"
            style={{ background: 'linear-gradient(135deg, #00c8d4, #1A7A8A)' }}
          >
            {t('nav.contactUs')}
          </Link>
        </div>
      </div>
    </>
  );
}