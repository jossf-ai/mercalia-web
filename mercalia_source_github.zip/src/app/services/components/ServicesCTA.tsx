'use client';

import React from 'react';
import { useLanguage } from '@/context/LanguageContext';

export default function ServicesCTA() {
  const { t } = useLanguage();
  const trustItems = [t('services.cta.trust.0'), t('services.cta.trust.1'), t('services.cta.trust.2')];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 md:px-10">
        <div className="relative rounded-3xl overflow-hidden py-14 px-8 md:px-14 text-center" style={{ background: 'linear-gradient(135deg, #071E33 0%, #0B2C4A 55%, #136070 100%)' }}>
          {/* Background glows */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-0 right-0 w-[400px] h-[400px] rounded-full opacity-15" style={{ background: 'radial-gradient(circle, #00c8d4 0%, transparent 70%)', transform: 'translate(25%, -25%)' }} />
            <div className="absolute bottom-0 left-0 w-[300px] h-[300px] rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #1A7A8A 0%, transparent 70%)', transform: 'translate(-20%, 20%)' }} />
            <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)', backgroundSize: '50px 50px' }} />
          </div>

          <div className="relative z-10">
            {/* Cyan accent line */}
            <div className="flex items-center justify-center gap-3 mb-6">
              <span className="w-8 h-px" style={{ background: '#00c8d4' }} />
              <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#00c8d4' }}>{t('services.cta.title')}</span>
              <span className="w-8 h-px" style={{ background: '#00c8d4' }} />
            </div>

            <h2 className="font-display font-bold text-white mb-5" style={{ fontSize: 'clamp(28px, 4vw, 44px)', letterSpacing: '-0.025em', lineHeight: '1.08' }}>
              {t('services.cta.title')}
            </h2>
            <p className="text-white/60 text-lg leading-relaxed mb-10 max-w-xl mx-auto">
              {t('services.cta.description')}{' '}
              <a href="mailto:contact@mercaliacg.com" style={{ color: '#00c8d4' }} className="hover:underline">contact@mercaliacg.com</a>
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <a
                href="https://wa.me/543425246765?text=MERCALIA%20/%20Attention%20in%20Latam.%0Athis%20is%20my%20query:"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-semibold text-sm transition-all duration-300 hover:-translate-y-1"
                style={{ background: 'linear-gradient(135deg, #00c8d4, #1A7A8A)', color: '#1a2332', boxShadow: '0 8px 32px rgba(0,200,212,0.3)' }}
              >
                {t('services.cta.whatsapp')}
                <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7" /></svg>
              </a>
              <a
                href="/contact"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-semibold text-sm text-white transition-all duration-300 hover:-translate-y-1"
                style={{ border: '1.5px solid rgba(0,200,212,0.4)', background: 'rgba(0,200,212,0.06)' }}
              >
                {t('services.cta.inquiry')}
              </a>
            </div>
            <div className="mt-8 flex flex-wrap gap-6 justify-center">
              {trustItems?.map((item) => (
                <div key={item} className="flex items-center gap-2 text-white/50 text-sm">
                  <svg width="14" height="14" fill="none" stroke="#00c8d4" strokeWidth="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}