'use client';

import React from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import { useLanguage } from '@/context/LanguageContext';

export default function FooterClient() {
  const { t } = useLanguage();

  const navLinks = [
    { labelKey: 'nav.home', href: '/homepage' },
    { labelKey: 'nav.services', href: '/services' },
    { labelKey: 'nav.products', href: '/products' },
    { labelKey: 'nav.compliance', href: '/compliance' },
    { labelKey: 'nav.contact', href: '/contact' },
  ];

  return (
    <footer className="relative overflow-hidden border-t border-white/10" style={{ background: 'linear-gradient(160deg, #1a2332 0%, #0B2C4A 50%, #0d3a4a 100%)' }}>
      {/* Top cyan accent line */}
      <div className="absolute top-0 left-0 right-0 h-[2px]" style={{ background: 'linear-gradient(90deg, transparent, #00c8d4 30%, #00c8d4 70%, transparent)' }} />

      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 right-0 w-[500px] h-[300px] rounded-full opacity-[0.06]" style={{ background: 'radial-gradient(circle, #00c8d4 0%, transparent 70%)', transform: 'translate(20%, 30%)' }} />
        <div className="absolute top-0 left-0 w-[300px] h-[300px] rounded-full opacity-[0.04]" style={{ background: 'radial-gradient(circle, #00c8d4 0%, transparent 70%)', transform: 'translate(-30%, -30%)' }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 py-14">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-10">
          {/* Logo + tagline */}
          <div className="flex flex-col gap-4">
            <Link href="/homepage" aria-label="MercaliaConnect Home">
              <AppLogo
                src="/assets/images/logo_mercalia_separado-1772891797274.png"
                size={88}
                className="opacity-95 hover:opacity-100 transition-opacity"
              />
            </Link>
            <p className="text-white/40 text-xs max-w-[220px] leading-relaxed">
              {t('footer.tagline')}
            </p>
          </div>

          {/* Nav links */}
          <nav className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
            {navLinks?.map((link) => (
              <Link
                key={link?.href}
                href={link?.href}
                className="text-sm font-medium text-white/50 hover:text-[#00c8d4] transition-colors duration-200"
              >
                {t(link?.labelKey)}
              </Link>
            ))}
          </nav>

          {/* Legal links */}
          <div className="flex flex-col gap-2">
            <Link href="/privacy" className="text-sm font-medium text-white/40 hover:text-[#00c8d4] transition-colors">{t('footer.privacy')}</Link>
            <Link href="/terms" className="text-sm font-medium text-white/40 hover:text-[#00c8d4] transition-colors">{t('footer.terms')}</Link>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-xs text-white/30">{t('footer.rights')}</p>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00c8d4] opacity-60" />
            <span className="text-xs text-white/25">New Mexico, USA · FinCEN Compliant</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
