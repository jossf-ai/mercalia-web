'use client';

import React, { useEffect, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';

const serviceIcons = [
  <svg key="0" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" /><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg>,
  <svg key="1" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" /><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2M12 12v4M10 14h4" /></svg>,
  <svg key="2" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M12 2v6M8 6l4-4 4 4M5 10h14l-1.5 9H6.5L5 10z" /><path d="M9 10v9M15 10v9" /></svg>,
  <svg key="3" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M12 22V12M12 12C12 7 7 3 2 3c0 5 4 9 10 9zM12 12c0-5 5-9 10-9-0 5-4 9-10 9z" /></svg>,
  <svg key="4" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20A10 10 0 0 0 12 2z" /><path d="M8 12s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01" /></svg>,
  <svg key="5" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" /></svg>,
];

export default function ServicesGrid() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { t } = useLanguage();

  useEffect(() => {
    const reveals = sectionRef?.current?.querySelectorAll('.reveal');
    if (!reveals) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach(e => { if (e.isIntersecting) e.target.classList.remove('hidden-init'); }),
      { threshold: 0.08 }
    );
    reveals?.forEach(el => observer?.observe(el));
    return () => observer?.disconnect();
  }, []);

  const services = [0, 1, 2, 3, 4, 5]?.map((i) => ({
    number: `0${i + 1}`,
    title: t(`services.${i}.title`),
    description: t(`services.${i}.description`),
    features: [
      t(`services.${i}.f0`),
      t(`services.${i}.f1`),
      t(`services.${i}.f2`),
      ...(i === 0 || i === 5 ? [t(`services.${i}.f3`)] : []),
    ]?.filter(Boolean),
    icon: serviceIcons?.[i],
  }));

  return (
    <section className="py-24 bg-white" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="mb-14">
          <span className="section-label block mb-3 reveal hidden-init">{t('services.grid.label')}</span>
          <h2 className="font-display font-bold text-primary reveal hidden-init stagger-1" style={{ fontSize: 'clamp(32px, 4vw, 48px)', letterSpacing: '-0.025em', lineHeight: '1.08' }}>
            {t('services.grid.title1')}
            <br />
            <span className="italic font-light text-secondary">{t('services.grid.titleItalic')}</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          <div className="bento-card md:col-span-7 p-8 md:p-10 reveal hidden-init stagger-1" style={{ minHeight: '300px' }}>
            <div className="relative h-full flex flex-col">
              <span className="service-number">{services?.[0]?.number}</span>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center text-secondary mb-6" style={{ background: 'rgba(26, 122, 138, 0.08)', border: '1px solid rgba(26,122,138,0.15)' }}>{services?.[0]?.icon}</div>
              <h3 className="font-display text-2xl font-bold text-primary mb-3" style={{ letterSpacing: '-0.015em' }}>{services?.[0]?.title}</h3>
              <p className="text-brand-muted leading-relaxed mb-6">{services?.[0]?.description}</p>
              <div className="mt-auto grid grid-cols-2 gap-2">
                {services?.[0]?.features?.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-brand-fg">
                    <span className="w-1.5 h-1.5 rounded-full bg-secondary flex-shrink-0" />{f}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bento-card md:col-span-5 p-8 reveal hidden-init stagger-2" style={{ minHeight: '300px' }}>
            <div className="relative h-full flex flex-col">
              <span className="service-number">{services?.[1]?.number}</span>
              <div className="w-11 h-11 rounded-xl flex items-center justify-center text-secondary mb-5" style={{ background: 'rgba(26, 122, 138, 0.08)', border: '1px solid rgba(26,122,138,0.15)' }}>{services?.[1]?.icon}</div>
              <h3 className="font-display text-xl font-bold text-primary mb-3" style={{ letterSpacing: '-0.015em' }}>{services?.[1]?.title}</h3>
              <p className="text-brand-muted text-sm leading-relaxed mb-5">{services?.[1]?.description}</p>
              <div className="mt-auto space-y-2">
                {services?.[1]?.features?.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-brand-fg">
                    <span className="w-1.5 h-1.5 rounded-full bg-secondary flex-shrink-0" />{f}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {services?.slice(2, 5)?.map((service, i) => (
            <div key={service?.number} className={`bento-card md:col-span-4 p-7 reveal hidden-init stagger-${i + 2}`} style={{ minHeight: '260px' }}>
              <div className="relative h-full flex flex-col">
                <span className="service-number">{service?.number}</span>
                <div className="w-11 h-11 rounded-xl flex items-center justify-center text-secondary mb-5" style={{ background: 'rgba(26, 122, 138, 0.08)', border: '1px solid rgba(26,122,138,0.15)' }}>{service?.icon}</div>
                <h3 className="font-display text-lg font-bold text-primary mb-2" style={{ letterSpacing: '-0.01em' }}>{service?.title}</h3>
                <p className="text-brand-muted text-sm leading-relaxed mb-4">{service?.description}</p>
                <div className="mt-auto space-y-1.5">
                  {service?.features?.map((f) => (
                    <div key={f} className="flex items-center gap-2 text-xs text-brand-fg">
                      <span className="w-1 h-1 rounded-full bg-secondary flex-shrink-0" />{f}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}

          <div className="bento-card md:col-span-12 p-8 md:p-10 reveal hidden-init stagger-4" style={{ background: 'linear-gradient(135deg, #0B2C4A 0%, #136070 100%)', border: 'none', minHeight: '200px' }}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-secondary" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)' }}>{services?.[5]?.icon}</div>
                  <span className="text-white/30 font-display text-5xl font-bold">{services?.[5]?.number}</span>
                </div>
                <h3 className="font-display text-2xl font-bold text-white mb-3" style={{ letterSpacing: '-0.015em' }}>{services?.[5]?.title}</h3>
                <p className="text-white/60 leading-relaxed">{services?.[5]?.description}</p>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {services?.[5]?.features?.map((f) => (
                  <div key={f} className="flex items-center gap-3 bg-white/5 rounded-xl px-4 py-3 border border-white/10">
                    <span className="w-2 h-2 rounded-full bg-secondary flex-shrink-0" />
                    <span className="text-white/80 text-sm font-medium">{f}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}